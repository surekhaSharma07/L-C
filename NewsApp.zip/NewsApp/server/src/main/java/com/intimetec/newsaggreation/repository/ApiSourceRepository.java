package com.intimetec.newsaggreation.repository;

import com.intimetec.newsaggreation.model.ApiSource;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ApiSourceRepository extends JpaRepository<ApiSource, Integer> {
}
