package com.intimetec.newsaggreation.model;

public enum ReactionType {
    LIKE,
    DISLIKE
}
