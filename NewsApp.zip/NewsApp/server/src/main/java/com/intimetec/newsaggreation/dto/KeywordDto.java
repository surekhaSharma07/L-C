package com.intimetec.newsaggreation.dto;


public record KeywordDto(Long id, String term) { }