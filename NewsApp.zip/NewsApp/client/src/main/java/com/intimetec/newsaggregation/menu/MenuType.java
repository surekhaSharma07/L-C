package com.intimetec.newsaggregation.menu;

public enum MenuType {
    WELCOME, USER, ADMIN,
    HEADLINE, SAVED, SEARCH, NOTIFICATIONS
}
