package com.intimetec.newsaggregation;

import com.intimetec.newsaggregation.app.ConsoleMenu;

public class NewsAggregationApplication {
    public static void main(String[] args) throws Exception {
        new ConsoleMenu().start();
    }
}
